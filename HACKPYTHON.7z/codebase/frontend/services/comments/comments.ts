import axiosInstance from "../axiosInstance"; 

export const CommentServices = { 
  getAllComments: () => { 
    return axiosInstance.get(`/api/comments/`); 
  }, 
}