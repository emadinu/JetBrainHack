export interface Comment {
    id: number;
    text: string;
    date_created: string; // ISO string e.g. "2025-04-06T12:34:56Z"
    date_last_modified: string;
    author: number;
    task: number;
  }
  