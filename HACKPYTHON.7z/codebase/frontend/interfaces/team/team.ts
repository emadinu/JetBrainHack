import { UserData } from '../userdata/userdata';
import { Payment } from '../payment/payment';

export interface Team {
    id: number;
    name: string;
    description: string;
    department: string;
    members: UserData[];
    dateCreated: Date;
    dateLastModified: Date;
    owner: UserData[];
    payments: Payment[];
}