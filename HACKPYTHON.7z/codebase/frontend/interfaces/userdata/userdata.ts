import { Team } from '../team/team';
import { Task } from '../task/task';

export interface UserData {
    id: number;
    name: string;
    email: string;
    dateJoined: Date;
    isStaff: boolean;
    type: string;
    teamsOwner: Team[];
    profilePicture: string;
    tasks: Task[];
}