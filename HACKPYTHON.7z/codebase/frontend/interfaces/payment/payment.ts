import { UserData } from '../userdata/userdata';
import { Team } from '../team/team';

export interface Payment {
    id: number;
    details: string;
    amount: number;
    month: string;
    year: number;
    recipient: UserData[];
    team: Team[];
}