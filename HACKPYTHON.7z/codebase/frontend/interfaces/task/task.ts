import { Team } from '../team/team';
import { UserData } from '../userdata/userdata';

export interface Task {
    id: number;
    summary: string;
    description: string;
    dateCreated: Date;
    startDate: Date;
    endDate: Date;
    estimation: number;
    type: string;
    team: Team;
    assignedTo: UserData;
    status: string;
    originalEstimate: number;
}