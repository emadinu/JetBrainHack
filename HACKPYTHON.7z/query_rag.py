import os
from dotenv import load_dotenv
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import OpenAIEmbeddings
from langchain_community.chat_models import ChatOpenAI
from langchain.chains import RetrievalQA
import logging
import tiktoken

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Load environment variables from .env
load_dotenv()

# Load API key
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    raise ValueError("Please set the OPENAI_API_KEY environment variable.")

# Embeddings and FAISS index path
embeddings = OpenAIEmbeddings(openai_api_key=api_key)
index_path = "faiss_index.pkl"
encoder = tiktoken.get_encoding("cl100k_base")

# Project description (can move to separate file)
project_description = '''You are provided with a request URL that points to a specific file within a project. Analyze the URL and generate a JSON containing the following fields:

filePath: Extract or infer the full path of the file from the URL, ensuring it aligns with the project's existing structure and architecture guidelines.

isNewFile: Determine whether the file at the provided filePath exists within the project. Return true if the file does not exist and false if it does.

fileContent: Retrieve or specify the content of the file. If the file is new, provide an appropriate default content or a template based on the file type and project requirements.
Ensure that the filePath is accurate and that isNewFile status is correctly identified to maintain system integrity.
If file and function already exist, return the existing file content and function. Return only the json object, nothing else.'''

def get_project_hierarchy(root_dir: str) -> str:
    hierarchy = []
    for dirpath, dirnames, filenames in os.walk(root_dir):
        level = dirpath.replace(root_dir, '').count(os.sep)
        indent = ' ' * 4 * level
        hierarchy.append(f"{indent}{os.path.basename(dirpath)}/")
        subindent = ' ' * 4 * (level + 1)
        for f in filenames:
            hierarchy.append(f"{subindent}{f}")
    return "\n".join(hierarchy)

def load_vector_store(index_path: str, embeddings) -> FAISS:
    logging.info("Loading vector store from disk...")
    vector_store = FAISS.load_local(index_path, embeddings, allow_dangerous_deserialization=True)
    logging.info("Vector store loaded successfully.")
    return vector_store

def initialize_qa_chain(vector_store: FAISS) -> RetrievalQA:
    chat_model = ChatOpenAI(
        openai_api_key=api_key,
        temperature=0.2,
        model_name="gpt-4"
    )
    qa_chain = RetrievalQA.from_chain_type(
        llm=chat_model,
        chain_type="stuff",
        retriever=vector_store.as_retriever(),
        return_source_documents=True
    )
    return qa_chain

def run_rag_query(query: str, mode: str = "1", root_dir: str = ".") -> str:

    vector_store = load_vector_store(index_path, embeddings)
    qa_chain = initialize_qa_chain(vector_store)

    filter_text = ""
    if mode == "0":
        filter_text = "Only consider files from the backend folder (e.g., codebase/backend/proj_backend)."
        root_dir = "codebase/backend"
    elif mode == "1":
        filter_text = "Only consider files from the frontend folder (e.g., codebase/frontend/services)."
        root_dir = "codebase/frontend"

    project_hierarchy = get_project_hierarchy(root_dir)

    full_query = (
        f"Project Hierarchy:\n{project_hierarchy}\n\n"
        f"Query: {query}\n\n"
        f"Project Description:\n{project_description}\n"
    )

    print("FULL QUERY: ", full_query)

    response = qa_chain.invoke({"query": full_query})

    result = response.get("result", "No result returned.")
    print("RESULT: ", result)
    return result

# For command line testing
if __name__ == "__main__":
    sample_query = "https://example.com/backend/api/users/new_user.py"
    response = run_rag_query(query=sample_query, mode="0")
    print("\nAnswer:\n", response)
