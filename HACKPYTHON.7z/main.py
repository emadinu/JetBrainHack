from fastapi import FastAPI, Form
from fastapi.middleware.cors import CORSMiddleware
from sentence_transformers import SentenceTransformer, util
import json
from typing import List, Dict
from query_rag import run_rag_query


app = FastAPI()
model = SentenceTransformer("all-MiniLM-L6-v2")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

def extract_subobjects(obj, parent_key=""):
    subobjects = []
    if isinstance(obj, dict):
        # Aici adăugăm direct obiectul curent (dacă are sub-câmpuri)
        if obj and all(isinstance(v, (dict, list, str, int, float, bool, type(None))) for v in obj.values()):
            subobjects.append((parent_key or "root", obj))

        for key, value in obj.items():
            if isinstance(value, dict):
                subobjects.append((key, value))
                subobjects.extend(extract_subobjects(value, key))
            elif isinstance(value, list) and value and isinstance(value[0], dict):
                subobjects.append((key, value[0]))
                subobjects.extend(extract_subobjects(value[0], key))
    return subobjects


@app.post("/match")
async def match_classes(
    classes: str = Form(...),
    response: str = Form(...)
) -> List[Dict[str, str]]:
    try:
        classes_data = json.loads(classes)
        print("--------------------------------")
        response_data = json.loads(response)
    except Exception as e:
        return {"error": f"Invalid JSON format: {e}"}

    # Encode clase
    class_embeddings = {}
    for cls in classes_data:
        name = cls["className"]
        fields = " ".join(cls["fields"])
        class_embeddings[name] = model.encode(fields)

    # Parse response JSON
    subobjects = []
    if isinstance(response_data, list):
        for i, obj in enumerate(response_data):
            subobjects.extend(extract_subobjects(obj, f"item_{i}"))
    else:
        subobjects.extend(extract_subobjects(response_data, "root"))

    suggestions = []
    for field_name, obj in subobjects:
        field_keys = " ".join(obj.keys())
        field_emb = model.encode(field_keys)

        best_match = None
        best_score = 0

        for class_name, class_emb in class_embeddings.items():
            score = util.cos_sim(field_emb, class_emb).item()
            if score > best_score:
                best_score = score
                best_match = class_name

        if best_score > 0.85:
            suggestions.append({
                "field": field_name,
                "matchesWith": best_match,
                "score": str(round(best_score, 3))  # ← convertit în string
            })

    print(suggestions)
    return suggestions

# Add a root endpoint for testing
@app.get("/")
def read_root():
    return {"message": "API is running"}


# POST endpoint to receive integration data
@app.post("/integrationCode")
async def receive_integration_code(
    requestType: str = Form(...),
    apiUrl: str = Form(...),
    JSONFormat: str = Form(...),
    module: int = Form(...)
) -> dict:
    import json

    try:
        query = f"I want to add a {requestType} at {apiUrl} API. The JSON format is: {JSONFormat}"
        result = run_rag_query(query, str(module), ".")

        lines = result.splitlines()

        # Găsește prima linie cu "{"
        start_index = next((i for i, line in enumerate(lines) if '{' in line), 0)

        # Găsește ultima linie cu "}"
        end_index = next((i for i in reversed(range(len(lines))) if '}' in lines[i]), len(lines) - 1)

        # Extrage doar blocul JSON
        cleaned_lines = lines[start_index:end_index + 1]
        cleaned_json_str = '\n'.join(cleaned_lines)

        print("RESULT: ", cleaned_json_str)

        # Parsează în dict
        cleaned_json = json.loads(cleaned_json_str)

        return cleaned_json

    except json.JSONDecodeError as e:
        raise HTTPException(status_code=400, detail=f"Invalid JSON: {str(e)}")

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")